package dao;

import entity.Plate;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PlateDAO {
    private Connection connection;

    public PlateDAO() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Initializing database connection inside PlateDAO constructor...");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/restaurant", "root", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Create a new Plate
    public boolean addPlate(Plate plate) {
        String query = "INSERT INTO plate (Plate_Name, Plate_Description, Plate_Price, Plate_Review, Plate_Image) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, plate.getPlateName());
            stmt.setString(2, plate.getPlateDescription());
            stmt.setDouble(3, plate.getPlatePrice());
            stmt.setString(4, plate.getPlateReview());
            stmt.setString(5, plate.getPlateImage());

            int result = stmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Read all Plates
    public List<Plate> getAllPlates() {
        List<Plate> plates = new ArrayList<>();
        String query = "SELECT * FROM plate";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Plate plate = new Plate(
                        rs.getInt("Plate_ID"),
                        rs.getString("Plate_Name"),
                        rs.getString("Plate_Description"),
                        rs.getDouble("Plate_Price"),
                        rs.getString("Plate_Review"),
                        rs.getString("Plate_Image")
                );
                plates.add(plate);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return plates;
    }

    // Get a Plate by ID
    public Plate getPlateById(int plateId) {
        String query = "SELECT * FROM plate WHERE Plate_ID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, plateId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Plate(
                        rs.getInt("Plate_ID"),
                        rs.getString("Plate_Name"),
                        rs.getString("Plate_Description"),
                        rs.getDouble("Plate_Price"),
                        rs.getString("Plate_Review"),
                        rs.getString("Plate_Image")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Update a Plate
    public boolean updatePlate(Plate plate) {
        String query = "UPDATE plate SET Plate_Name = ?, Plate_Description = ?, Plate_Price = ?, Plate_Review = ?, Plate_Image = ? WHERE Plate_ID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, plate.getPlateName());
            stmt.setString(2, plate.getPlateDescription());
            stmt.setDouble(3, plate.getPlatePrice());
            stmt.setString(4, plate.getPlateReview());
            stmt.setString(5, plate.getPlateImage());
            stmt.setInt(6, plate.getPlateId());

            int result = stmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Delete a Plate
    public boolean deletePlate(int plateId) {
        String query = "DELETE FROM plate WHERE Plate_ID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, plateId);
            int result = stmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}