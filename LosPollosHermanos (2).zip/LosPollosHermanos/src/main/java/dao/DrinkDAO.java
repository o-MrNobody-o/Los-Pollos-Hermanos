package dao;

import entity.Drink;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DrinkDAO {
    private Connection connection;

    public DrinkDAO() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Initializing database connection inside DrinkDAO constructor...");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/restaurant", "root", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Create a new Drink
    public boolean addDrink(Drink drink) {
        String query = "INSERT INTO drink (Drink_Name, Drink_Description, Drink_Price, Drink_Review, Drink_Image) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, drink.getDrinkName());
            stmt.setString(2, drink.getDrinkDescription());
            stmt.setDouble(3, drink.getDrinkPrice());
            stmt.setString(4, drink.getDrinkReview());
            stmt.setString(5, drink.getDrinkImage());

            int result = stmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Read all Drinks
    public List<Drink> getAllDrinks() {
        List<Drink> drinks = new ArrayList<>();
        String query = "SELECT * FROM drink";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Drink drink = new Drink(
                        rs.getInt("Drink_ID"),
                        rs.getString("Drink_Name"),
                        rs.getString("Drink_Description"),
                        rs.getDouble("Drink_Price"),
                        rs.getString("Drink_Review"),
                        rs.getString("Drink_Image")
                );
                drinks.add(drink);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return drinks;
    }

    // Get a Drink by ID
    public Drink getDrinkById(int drinkId) {
        String query = "SELECT * FROM drink WHERE Drink_ID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, drinkId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Drink(
                        rs.getInt("Drink_ID"),
                        rs.getString("Drink_Name"),
                        rs.getString("Drink_Description"),
                        rs.getDouble("Drink_Price"),
                        rs.getString("Drink_Review"),
                        rs.getString("Drink_Image")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Update a Drink
    public boolean updateDrink(Drink drink) {
        String query = "UPDATE drink SET Drink_Name = ?, Drink_Description = ?, Drink_Price = ?, Drink_Review = ?, Drink_Image = ? WHERE Drink_ID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, drink.getDrinkName());
            stmt.setString(2, drink.getDrinkDescription());
            stmt.setDouble(3, drink.getDrinkPrice());
            stmt.setString(4, drink.getDrinkReview());
            stmt.setString(5, drink.getDrinkImage());
            stmt.setInt(6, drink.getDrinkId());

            int result = stmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Delete a Drink
    public boolean deleteDrink(int drinkId) {
        String query = "DELETE FROM drink WHERE Drink_ID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, drinkId);
            int result = stmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
