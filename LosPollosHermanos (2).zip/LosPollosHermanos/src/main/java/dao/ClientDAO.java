package dao;

import entity.Client;
import utility.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClientDAO {
    private Connection connection;

    public ClientDAO() 
    	{
    	    try {
    	        Class.forName("com.mysql.cj.jdbc.Driver"); // Register driver
    	        System.out.println("Initializing database connection inside DAO constructor...");
    	        connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/restaurant", "root", "");
    	    } catch (Exception e) {
    	        e.printStackTrace();
    	    }
    	}


    // Create a new Client
    public boolean addClient(Client client) {
        String query = "INSERT INTO client (Client_First_Name, Client_Last_Name, Client_Phone, Client_Email, Client_Address) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, client.getFirstName());
            stmt.setString(2, client.getLastName());
            stmt.setString(3, client.getPhone());
            stmt.setString(4, client.getEmail());
            stmt.setString(5, client.getAddress());

            int result = stmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Read all Clients
    public List<Client> getAllClients() {
        List<Client> clients = new ArrayList<>();
        String query = "SELECT * FROM client";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Client client = new Client(
                        rs.getInt("Client_ID"),
                        rs.getString("Client_First_Name"),
                        rs.getString("Client_Last_Name"),
                        rs.getString("Client_Phone"),
                        rs.getString("Client_Email"),
                        rs.getString("Client_Address")
                );
                clients.add(client);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return clients;
    }

    // Get a Client by ID
    public Client getClientById(int clientId) {
        String query = "SELECT * FROM client WHERE Client_ID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, clientId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Client(
                        rs.getInt("Client_ID"),
                        rs.getString("Client_First_Name"),
                        rs.getString("Client_Last_Name"),
                        rs.getString("Client_Phone"),
                        rs.getString("Client_Email"),
                        rs.getString("Client_Address")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Update a Client
    public boolean updateClient(Client client) {
        String query = "UPDATE client SET Client_First_Name = ?, Client_Last_Name = ?, Client_Phone = ?, Client_Email = ?, Client_Address = ? WHERE Client_ID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, client.getFirstName());
            stmt.setString(2, client.getLastName());
            stmt.setString(3, client.getPhone());
            stmt.setString(4, client.getEmail());
            stmt.setString(5, client.getAddress());
            stmt.setInt(6, client.getClientId());

            int result = stmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Delete a Client
    public boolean deleteClient(int clientId) {
        String query = "DELETE FROM client WHERE Client_ID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, clientId);
            int result = stmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
