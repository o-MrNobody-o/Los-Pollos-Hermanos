package dao;

import entity.Booth;
import utility.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BoothDAO {
    private Connection connection;

    public BoothDAO() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Initializing database connection inside BoothDAO constructor...");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/restaurant", "root", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Create a new Booth
    public boolean addBooth(Booth booth) {
        String query = "INSERT INTO booth (Booth_Capacity, Booth_Type, Booth_Availability) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, booth.getCapacity());
            stmt.setString(2, booth.getType());
            stmt.setBoolean(3, booth.isAvailability());

            int result = stmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Read all Booths
    public List<Booth> getAllBooths() {
        List<Booth> booths = new ArrayList<>();
        String query = "SELECT * FROM booth";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Booth booth = new Booth(
                        rs.getInt("Booth_ID"),
                        rs.getInt("Booth_Capacity"),
                        rs.getString("Booth_Type"),
                        rs.getBoolean("Booth_Availability") // Retrieve availability from database
                );
                booths.add(booth);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return booths;
    }

    // Get a Booth by ID
    public Booth getBoothById(int boothId) {
        String query = "SELECT * FROM booth WHERE Booth_ID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, boothId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Booth(
                        rs.getInt("Booth_ID"),
                        rs.getInt("Booth_Capacity"),
                        rs.getString("Booth_Type"),
                        rs.getBoolean("Booth_Availability") // Retrieve availability from database
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Update a Booth
    public boolean updateBooth(Booth booth) {
        String query = "UPDATE booth SET Booth_Capacity = ?, Booth_Type = ?, Booth_Availability = ? WHERE Booth_ID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, booth.getCapacity());
            stmt.setString(2, booth.getType());
            stmt.setBoolean(3, booth.isAvailability());
            stmt.setInt(4, booth.getBoothId());

            int result = stmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Delete a Booth
    public boolean deleteBooth(int boothId) {
        String query = "DELETE FROM booth WHERE Booth_ID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, boothId);
            int result = stmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
