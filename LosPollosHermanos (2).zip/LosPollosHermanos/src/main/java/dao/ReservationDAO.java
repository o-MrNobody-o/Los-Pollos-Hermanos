package dao;

import entity.Reservation;
import utility.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReservationDAO {
    private Connection connection;

    public ReservationDAO() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Ensure driver is loaded
            System.out.println("Initializing database connection inside ReservationDAO constructor...");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/restaurant", "root", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean addReservation(Reservation reservation) {
        String sql = "INSERT INTO reservation (Client_ID, Booth_ID, Reservation_Date, Reservation_CheckIN, Reservation_CheckOut) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, reservation.getClientId());
            stmt.setInt(2, reservation.getBoothId());
            stmt.setDate(3, reservation.getReservationDate());
            stmt.setTime(4, reservation.getReservationCheckIN());
            stmt.setTime(5, reservation.getReservationCheckOut());

            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public Reservation getReservationById(int id) {
        String sql = "SELECT * FROM reservation WHERE Reservation_ID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapReservation(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Reservation> getAllReservations() {
        List<Reservation> list = new ArrayList<>();
        String sql = "SELECT * FROM reservation";
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                list.add(mapReservation(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public boolean updateReservation(Reservation reservation) {
        String sql = "UPDATE reservation SET Client_ID=?, Booth_ID=?, Reservation_Date=?, Reservation_CheckIN=?, Reservation_CheckOut=? WHERE Reservation_ID=?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, reservation.getClientId());
            stmt.setInt(2, reservation.getBoothId());
            stmt.setDate(3, reservation.getReservationDate());
            stmt.setTime(4, reservation.getReservationCheckIN());
            stmt.setTime(5, reservation.getReservationCheckOut());
            stmt.setInt(6, reservation.getReservationId());

            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean deleteReservation(int id) {
        String sql = "DELETE FROM reservation WHERE Reservation_ID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private Reservation mapReservation(ResultSet rs) throws SQLException {
        Reservation reservation = new Reservation();
        reservation.setReservationId(rs.getInt("Reservation_ID"));
        reservation.setClientId(rs.getInt("Client_ID"));
        reservation.setBoothId(rs.getInt("Booth_ID"));
        reservation.setReservationDate(rs.getDate("Reservation_Date"));
        reservation.setReservationCheckIN(rs.getTime("Reservation_CheckIN"));
        reservation.setReservationCheckOut(rs.getTime("Reservation_CheckOut"));
        return reservation;
    }
}
