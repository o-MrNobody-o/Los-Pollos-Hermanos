package controller;

import entity.Drink;
import model.DrinkModel;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/drinks")
public class DrinkServlet extends HttpServlet {
    private DrinkModel drinkModel;

    @Override
    public void init() {
        drinkModel = new DrinkModel();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) action = "list";

        switch (action) {
            case "list":
                listDrinks(request, response);
                break;
            case "showAddForm":
                showForm(request, response, new Drink(), "add");
                break;
            case "showEditForm":
                showEditForm(request, response);
                break;
            case "delete":
                deleteDrink(request, response);
                break;
            default:
                listDrinks(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("add".equals(action)) {
            addDrink(request, response);
        } else if ("edit".equals(action)) {
            updateDrink(request, response);
        } else {
            response.sendRedirect("drinks?action=list");
        }
    }

    private void listDrinks(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Drink> drinks = drinkModel.getAllDrinks();
        request.setAttribute("drinkList", drinks);
        request.getRequestDispatcher("pages/drink-list.jsp").forward(request, response);
    }

    private void showForm(HttpServletRequest request, HttpServletResponse response, Drink drink, String action)
            throws ServletException, IOException {
        request.setAttribute("drink", drink);
        request.setAttribute("formAction", action);
        request.getRequestDispatcher("pages/drink-form.jsp").forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String idStr = request.getParameter("id");
        if (idStr == null) {
            response.sendRedirect("drinks?action=list");
            return;
        }

        int id = Integer.parseInt(idStr);
        Drink drink = drinkModel.getDrinkById(id);
        if (drink == null) {
            response.sendRedirect("drinks?action=list");
            return;
        }

        showForm(request, response, drink, "edit");
    }

    private void deleteDrink(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        String idStr = request.getParameter("id");
        if (idStr != null) {
            int id = Integer.parseInt(idStr);
            drinkModel.deleteDrink(id);
        }
        response.sendRedirect("drinks?action=list");
    }

    private void addDrink(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        Drink drink = getDrinkFromRequest(request);
        drinkModel.createDrink(drink);
        response.sendRedirect("drinks?action=list");
    }

    private void updateDrink(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        Drink drink = getDrinkFromRequest(request);
        String idStr = request.getParameter("id");
        if (idStr != null) {
            drink.setDrinkId(Integer.parseInt(idStr));
        }
        drinkModel.updateDrink(drink);
        response.sendRedirect("drinks?action=list");
    }

    private Drink getDrinkFromRequest(HttpServletRequest request) {
        Drink drink = new Drink();
        drink.setDrinkName(request.getParameter("name"));
        drink.setDrinkDescription(request.getParameter("description"));
        drink.setDrinkReview(request.getParameter("review"));
        drink.setDrinkImage(request.getParameter("image"));

        String priceStr = request.getParameter("price");
        float price = 0.0f;
        if (priceStr != null && !priceStr.trim().isEmpty()) {
            try {
                price = Float.parseFloat(priceStr.trim());
            } catch (NumberFormatException e) {
                // Optional: log error
                price = 0.0f;
            }
        }
        drink.setDrinkPrice(price);

        return drink;
    }
}
