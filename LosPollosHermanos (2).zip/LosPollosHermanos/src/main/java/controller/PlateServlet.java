package controller;

import entity.Plate;
import model.PlateModel;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/plates")
public class PlateServlet extends HttpServlet {
    private PlateModel plateModel;

    @Override
    public void init() {
        plateModel = new PlateModel();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) {
            action = "list";
        }

        switch (action) {
            case "list":
                listPlates(request, response);
                break;
            case "new":
                showForm(request, response, new Plate(), "add");
                break;
            case "edit":
                showEditForm(request, response);
                break;
            case "delete":
                deletePlate(request, response);
                break;
            default:
                listPlates(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("add".equals(action)) {
            addPlate(request, response);
        } else if ("edit".equals(action)) {
            updatePlate(request, response);
        } else {
            response.sendRedirect("plates?action=list");
        }
    }

    private void listPlates(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Plate> plateList = plateModel.getAllPlates();
        request.setAttribute("plateList", plateList);
        request.getRequestDispatcher("pages/plate-list.jsp").forward(request, response);
    }

    private void showForm(HttpServletRequest request, HttpServletResponse response, Plate plate, String formAction)
            throws ServletException, IOException {
        request.setAttribute("plate", plate);
        request.setAttribute("formAction", formAction);
        request.getRequestDispatcher("pages/plate-form.jsp").forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String idStr = request.getParameter("id");
        if (idStr == null || idStr.trim().isEmpty()) {
            response.sendRedirect("plates?action=list");
            return;
        }

        int id = Integer.parseInt(idStr);
        Plate plate = plateModel.getPlateById(id);
        if (plate == null) {
            response.sendRedirect("plates?action=list");
            return;
        }

        showForm(request, response, plate, "edit");
    }

    private void deletePlate(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        String idStr = request.getParameter("id");
        if (idStr != null && !idStr.trim().isEmpty()) {
            int id = Integer.parseInt(idStr);
            plateModel.deletePlate(id);
        }
        response.sendRedirect("plates?action=list");
    }

    private void addPlate(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        Plate plate = getPlateFromRequest(request);
        plateModel.createPlate(plate);
        response.sendRedirect("plates?action=list");
    }

    private void updatePlate(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        Plate plate = getPlateFromRequest(request);
        String idStr = request.getParameter("id");
        if (idStr != null && !idStr.trim().isEmpty()) {
            plate.setPlateId(Integer.parseInt(idStr));
        }
        plateModel.updatePlate(plate);
        response.sendRedirect("plates?action=list");
    }

    private Plate getPlateFromRequest(HttpServletRequest request) {
        Plate plate = new Plate();
        plate.setPlateName(request.getParameter("name"));
        plate.setPlateDescription(request.getParameter("description"));
        plate.setPlateReview(request.getParameter("review"));
        plate.setPlateImage(request.getParameter("image"));

        String priceStr = request.getParameter("price");
        double price = 0.0;
        if (priceStr != null && !priceStr.trim().isEmpty()) {
            try {
                price = Double.parseDouble(priceStr.trim());
            } catch (NumberFormatException e) {
                price = 0.0;
            }
        }
        plate.setPlatePrice(price);

        return plate;
    }
}
