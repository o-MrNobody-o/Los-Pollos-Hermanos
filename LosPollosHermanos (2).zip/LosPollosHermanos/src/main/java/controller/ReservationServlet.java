package controller;

import entity.Reservation;
import entity.Client;
import entity.Booth;
import model.ReservationModel;
import model.ClientModel;
import model.BoothModel;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/reservation")
public class ReservationServlet extends HttpServlet {
    private ReservationModel reservationModel;
    private ClientModel clientModel;
    private BoothModel boothModel;

    @Override
    public void init() {
        reservationModel = new ReservationModel();
        clientModel = new ClientModel();
        boothModel = new BoothModel();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        try {
            if (action == null) {
                action = "list";
            }

            switch (action) {
                case "new":
                    showNewForm(request, response);
                    break;
                case "edit":
                    showEditForm(request, response);
                    break;
                case "delete":
                    deleteReservation(request, response);
                    break;
                default:
                    listReservations(request, response);
                    break;
            }
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String id = request.getParameter("reservationId");

        String clientId = request.getParameter("clientId");
        String boothId = request.getParameter("boothId");
        String reservationDate = request.getParameter("reservationDate");
        String checkIn = request.getParameter("checkin");
        String checkOut = request.getParameter("checkout");
        
        // Log the values to check what is coming from the form
        System.out.println("CheckIn Time: " + checkIn);
        System.out.println("CheckOut Time: " + checkOut);

        // Ensure checkIn and checkOut are valid
        if (checkIn == null || checkIn.isEmpty() || checkOut == null || checkOut.isEmpty()) {
            throw new IllegalArgumentException("Check-In and Check-Out times cannot be empty.");
        }

        // Ensure the time format is HH:mm (If it is HH:mm, append ":00" to make it HH:mm:ss)
        if (checkIn.length() == 5) {
            checkIn = checkIn + ":00"; // Append :00 to make it HH:mm:ss
        }

        if (checkOut.length() == 5) {
            checkOut = checkOut + ":00"; // Append :00 to make it HH:mm:ss
        }

        // Convert to java.sql.Time
        java.sql.Time checkInTime = java.sql.Time.valueOf(checkIn);
        java.sql.Time checkOutTime = java.sql.Time.valueOf(checkOut);

        Reservation reservation;

        if (id == null || id.isEmpty()) {
            // Create a new reservation
            reservation = new Reservation(
                    Integer.parseInt(clientId),
                    Integer.parseInt(boothId),
                    java.sql.Date.valueOf(reservationDate),
                    checkInTime,
                    checkOutTime
            );
            reservationModel.createReservation(reservation);
        } else {
            // Update existing reservation
            int reservationId = Integer.parseInt(id);
            reservation = new Reservation(
                    reservationId,
                    Integer.parseInt(clientId),
                    Integer.parseInt(boothId),
                    java.sql.Date.valueOf(reservationDate),
                    checkInTime,
                    checkOutTime
            );
            reservationModel.updateReservation(reservation);
        }

        response.sendRedirect("reservation");
    }


    private void listReservations(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Reservation> reservations = reservationModel.getAllReservations();
        request.setAttribute("reservationList", reservations);
        RequestDispatcher dispatcher = request.getRequestDispatcher("pages/reservation-list.jsp");
        dispatcher.forward(request, response);
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Client> clientList = clientModel.getAllClients();
        List<Booth> boothList = boothModel.getAllBooths();

        request.setAttribute("clientList", clientList);
        request.setAttribute("boothList", boothList);

        RequestDispatcher dispatcher = request.getRequestDispatcher("pages/reservation-form.jsp");
        dispatcher.forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        Reservation existingReservation = reservationModel.getReservationById(id);

        List<Client> clientList = clientModel.getAllClients();
        List<Booth> boothList = boothModel.getAllBooths();

        request.setAttribute("reservation", existingReservation);
        request.setAttribute("clientList", clientList);
        request.setAttribute("boothList", boothList);

        RequestDispatcher dispatcher = request.getRequestDispatcher("pages/reservation-form.jsp");
        dispatcher.forward(request, response);
    }

    private void deleteReservation(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        reservationModel.deleteReservation(id);
        response.sendRedirect("reservation");
    }
}
