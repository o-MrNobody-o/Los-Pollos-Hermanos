package controller;

import entity.Booth;
import model.BoothModel;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/booth")
public class BoothServlet extends HttpServlet {
    private BoothModel boothModel;

    @Override
    public void init() {
        boothModel = new BoothModel();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        try {
            if (action == null) {
                action = "list";
            }

            switch (action) {
                case "new":
                    showNewForm(request, response);
                    break;
                case "edit":
                    showEditForm(request, response);
                    break;
                case "delete":
                    deleteBooth(request, response);
                    break;
                default:
                    listBooths(request, response);
                    break;
            }
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String id = request.getParameter("id");
        
        String capacity = request.getParameter("capacity");
        String type = request.getParameter("type"); // This will be either "Indoor" or "Outdoor"
        String availabilityStr = request.getParameter("availability"); // "true" or "false"
        boolean availability = Boolean.parseBoolean(availabilityStr);

        Booth booth;

        if (id == null || id.isEmpty()) {
            booth = new Booth(Integer.parseInt(capacity), type, availability);
            boothModel.createBooth(booth);
        } else {
            int boothId = Integer.parseInt(id);
            booth = new Booth(boothId, Integer.parseInt(capacity), type, availability);
            boothModel.updateBooth(booth);
        }

        response.sendRedirect("booth");
    }

    private void listBooths(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Booth> booths = boothModel.getAllBooths();
        request.setAttribute("boothList", booths);
        RequestDispatcher dispatcher = request.getRequestDispatcher("pages/booth-list.jsp");
        dispatcher.forward(request, response);
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("pages/booth-form.jsp");
        dispatcher.forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        Booth existingBooth = boothModel.getBoothById(id);
        request.setAttribute("booth", existingBooth);
        RequestDispatcher dispatcher = request.getRequestDispatcher("pages/booth-form.jsp");
        dispatcher.forward(request, response);
    }

    private void deleteBooth(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        boothModel.deleteBooth(id);
        response.sendRedirect("booth");
    }
}
