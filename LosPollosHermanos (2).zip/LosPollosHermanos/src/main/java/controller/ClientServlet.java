package controller;

import entity.Client;
import model.ClientModel;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/client")
public class ClientServlet extends HttpServlet {
    private ClientModel clientModel;

    @Override
    public void init() {
        clientModel = new ClientModel();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        try {
            if (action == null) {
                action = "list";
            }

            switch (action) {
                case "new":
                    showNewForm(request, response);
                    break;
                case "edit":
                    showEditForm(request, response);
                    break;
                case "delete":
                    deleteClient(request, response);
                    break;
                default:
                    listClients(request, response);
                    break;
            }
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String id = request.getParameter("id");

        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String phone = request.getParameter("phone");
        String email = request.getParameter("email");
        String address = request.getParameter("address");

        Client client;

        if (id == null || id.isEmpty()) {
            client = new Client(firstName, lastName, phone, email, address);
            clientModel.createClient(client);
        } else {
            int clientId = Integer.parseInt(id);
            client = new Client(clientId, firstName, lastName, phone, email, address);
            clientModel.updateClient(client);
        }

        response.sendRedirect("client");
    }

    private void listClients(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Client> clients = clientModel.getAllClients();
        request.setAttribute("clientList", clients);
        RequestDispatcher dispatcher = request.getRequestDispatcher("pages/client-list.jsp");
        dispatcher.forward(request, response);
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("pages/client-form.jsp");
        dispatcher.forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        Client existingClient = clientModel.getClientById(id);
        request.setAttribute("client", existingClient);
        RequestDispatcher dispatcher = request.getRequestDispatcher("pages/client-form.jsp");
        dispatcher.forward(request, response);
    }

    private void deleteClient(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        clientModel.deleteClient(id);
        response.sendRedirect("client");
    }
}
