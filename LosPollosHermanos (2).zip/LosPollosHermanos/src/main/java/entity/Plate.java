package entity;

public class Plate {
    private int plateId;
    private double platePrice;
    private String plateDescription;
    private String plateName;
    private String plateReview;
    private String plateImage;

    // Default constructor
    public Plate() {}
    
    public Plate( String plateName, String plateDescription, double platePrice, String plateReview, String plateImage) {
        this.plateName = plateName;
        this.plateDescription = plateDescription;
        this.platePrice = platePrice;
        this.plateReview = plateReview;
        this.plateImage = plateImage;
    }

    // Parameterized constructor (useful for full CRUD)
    public Plate(int plateId, String plateName, String plateDescription, double platePrice, String plateReview, String plateImage) {
        this.plateId = plateId;
        this.plateName = plateName;
        this.plateDescription = plateDescription;
        this.platePrice = platePrice;
        this.plateReview = plateReview;
        this.plateImage = plateImage;
    }

    // Getters and Setters
    public int getPlateId() { return plateId; }
    public void setPlateId(int plateId) { this.plateId = plateId; }

    public double getPlatePrice() { return platePrice; }
    public void setPlatePrice(double platePrice) { this.platePrice = platePrice; }

    public String getPlateDescription() { return plateDescription; }
    public void setPlateDescription(String plateDescription) { this.plateDescription = plateDescription; }

    public String getPlateName() { return plateName; }
    public void setPlateName(String plateName) { this.plateName = plateName; }

    public String getPlateReview() { return plateReview; }
    public void setPlateReview(String plateReview) { this.plateReview = plateReview; }

    public String getPlateImage() { return plateImage; }
    public void setPlateImage(String plateImage) { this.plateImage = plateImage; }
}
