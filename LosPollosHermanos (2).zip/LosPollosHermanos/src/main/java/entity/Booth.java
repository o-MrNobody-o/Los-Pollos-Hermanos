package entity;

public class Booth {
    private int boothId;
    private int capacity;
    private String type; // 'Indoor' or 'Outdoor'
    private boolean availability; // true or false for availability

    // Constructors
    public Booth() {}

    public Booth(int boothId, int capacity, String type, boolean availability) {
        this.boothId = boothId;
        this.capacity = capacity;
        this.type = type;
        this.availability = availability;
    }

    public Booth(int capacity, String type, boolean availability) {
        this.capacity = capacity;
        this.type = type;
        this.availability = availability;
    }

    // Getters and Setters
    public int getBoothId() {
        return boothId;
    }

    public void setBoothId(int boothId) {
        this.boothId = boothId;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isAvailability() {
        return availability;
    }

    public void setAvailability(boolean availability) {
        this.availability = availability;
    }

    // toString
    @Override
    public String toString() {
        return "Booth{" +
                "boothId=" + boothId +
                ", capacity=" + capacity +
                ", type='" + type + '\'' +
                ", availability=" + availability +
                '}';
    }
}
