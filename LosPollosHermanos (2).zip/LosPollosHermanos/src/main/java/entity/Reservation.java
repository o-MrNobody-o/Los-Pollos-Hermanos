package entity;

import java.sql.Date;
import java.sql.Time;

public class Reservation {
    private int reservationId;
    private int clientId;
    private int boothId;
    private Date reservationDate;
    private Time reservationCheckIN;
    private Time reservationCheckOut;

    // Constructors
    public Reservation() {
    }

    public Reservation(int reservationId, int clientId, int boothId, Date reservationDate, Time reservationCheckIN, Time reservationCheckOut) {
        this.reservationId = reservationId;
        this.clientId = clientId;
        this.boothId = boothId;
        this.reservationDate = reservationDate;
        this.reservationCheckIN = reservationCheckIN;
        this.reservationCheckOut = reservationCheckOut;
    }
    
    public Reservation(int clientId, int boothId, Date reservationDate, Time checkIn, Time checkOut) {
        this.clientId = clientId;
        this.boothId = boothId;
        this.reservationDate = reservationDate;
        this.reservationCheckIN = checkIn;
        this.reservationCheckOut = checkOut;
    }

    // Getters and Setters
    public int getReservationId() {
        return reservationId;
    }

    public void setReservationId(int reservationId) {
        this.reservationId = reservationId;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public int getBoothId() {
        return boothId;
    }

    public void setBoothId(int boothId) {
        this.boothId = boothId;
    }

    public Date getReservationDate() {
        return reservationDate;
    }

    public void setReservationDate(Date reservationDate) {
        this.reservationDate = reservationDate;
    }

    public Time getReservationCheckIN() {
        return reservationCheckIN;
    }

    public void setReservationCheckIN(Time reservationCheckIN) {
        this.reservationCheckIN = reservationCheckIN;
    }

    public Time getReservationCheckOut() {
        return reservationCheckOut;
    }

    public void setReservationCheckOut(Time reservationCheckOut) {
        this.reservationCheckOut = reservationCheckOut;
    }
}
