package entity;

public class Drink {
    private int drinkId;
    private double drinkPrice;
    private String drinkDescription;
    private String drinkName;
    private String drinkReview;
    private String drinkImage;

    // Default constructor
    public Drink() {}

    public Drink(String drinkName, String drinkDescription, double drinkPrice, String drinkReview, String drinkImage) {
        this.drinkName = drinkName;
        this.drinkDescription = drinkDescription;
        this.drinkPrice = drinkPrice;
        this.drinkReview = drinkReview;
        this.drinkImage = drinkImage;
    }

    // Parameterized constructor (useful for full CRUD)
    public Drink(int drinkId, String drinkName, String drinkDescription, double drinkPrice, String drinkReview, String drinkImage) {
        this.drinkId = drinkId;
        this.drinkName = drinkName;
        this.drinkDescription = drinkDescription;
        this.drinkPrice = drinkPrice;
        this.drinkReview = drinkReview;
        this.drinkImage = drinkImage;
    }

    // Getters and Setters
    public int getDrinkId() { return drinkId; }
    public void setDrinkId(int drinkId) { this.drinkId = drinkId; }

    public double getDrinkPrice() { return drinkPrice; }
    public void setDrinkPrice(double drinkPrice) { this.drinkPrice = drinkPrice; }

    public String getDrinkDescription() { return drinkDescription; }
    public void setDrinkDescription(String drinkDescription) { this.drinkDescription = drinkDescription; }

    public String getDrinkName() { return drinkName; }
    public void setDrinkName(String drinkName) { this.drinkName = drinkName; }

    public String getDrinkReview() { return drinkReview; }
    public void setDrinkReview(String drinkReview) { this.drinkReview = drinkReview; }

    public String getDrinkImage() { return drinkImage; }
    public void setDrinkImage(String drinkImage) { this.drinkImage = drinkImage; }
}
