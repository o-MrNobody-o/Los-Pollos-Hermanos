package utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    public static final String URL = "jdbc:mysql://localhost:3306/restaurant";
    public static final String USER = "root";
    public static final String PASSWORD = "";

    private static Connection connection = null;

    // Private constructor to prevent instantiation
    private DBConnection() {}

    // Singleton access point with thread-safety (double-checked locking)
    public static Connection getConnection() {
        if (connection == null) {
            synchronized (DBConnection.class) {
                if (connection == null) {
                    try {
                        System.out.println("Attempting to connect to the database...");
                        Class.forName("com.mysql.cj.jdbc.Driver");
                        connection = DriverManager.getConnection(URL, USER, PASSWORD);
                        System.out.println("Database connected successfully.");
                    } catch (ClassNotFoundException | SQLException e) {
                        System.out.println("Error connecting to database: " + e.getMessage());
                        e.printStackTrace();
                    }
                }
            }
        }
        return connection;
    }
}

