package model;

import dao.ReservationDAO;
import entity.Reservation;

import java.util.List;

public class ReservationModel {

    private ReservationDAO reservationDAO;

    public ReservationModel() {
        reservationDAO = new ReservationDAO();
    }

    // Create a new Reservation
    public boolean createReservation(Reservation reservation) {
        return reservationDAO.addReservation(reservation);
    }

    // Get all Reservations
    public List<Reservation> getAllReservations() {
        return reservationDAO.getAllReservations();
    }

    // Get a specific Reservation by ID
    public Reservation getReservationById(int reservationId) {
        return reservationDAO.getReservationById(reservationId);
    }

    // Update a Reservation
    public boolean updateReservation(Reservation reservation) {
        return reservationDAO.updateReservation(reservation);
    }

    // Delete a Reservation
    public boolean deleteReservation(int reservationId) {
        return reservationDAO.deleteReservation(reservationId);
    }
}
