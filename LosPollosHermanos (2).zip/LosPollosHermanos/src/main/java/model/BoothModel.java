package model;

import dao.BoothDAO;
import entity.Booth;

import java.util.List;

public class BoothModel {

    private BoothDAO boothDAO;

    public BoothModel() {
        boothDAO = new BoothDAO();
    }

    // Create a new Booth
    public boolean createBooth(Booth booth) {
        return boothDAO.addBooth(booth);
    }

    // Get all Booths
    public List<Booth> getAllBooths() {
        return boothDAO.getAllBooths();
    }

    // Get a specific Booth by ID
    public Booth getBoothById(int boothId) {
        return boothDAO.getBoothById(boothId);
    }

    // Update a Booth
    public boolean updateBooth(Booth booth) {
        return boothDAO.updateBooth(booth);
    }

    // Delete a Booth
    public boolean deleteBooth(int boothId) {
        return boothDAO.deleteBooth(boothId);
    }
}
