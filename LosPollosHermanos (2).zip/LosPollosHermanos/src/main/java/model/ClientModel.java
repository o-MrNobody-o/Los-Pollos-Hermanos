package model;

import dao.ClientDAO;
import entity.Client;

import java.util.List;

public class ClientModel {
    private ClientDAO clientDAO;

    public ClientModel() {
        clientDAO = new ClientDAO();
    }

    public boolean createClient(Client client) {
        return clientDAO.addClient(client);
    }

    public List<Client> getAllClients() {
        return clientDAO.getAllClients();
    }

    public Client getClientById(int id) {
        return clientDAO.getClientById(id);
    }

    public boolean updateClient(Client client) {
        return clientDAO.updateClient(client);
    }

    public boolean deleteClient(int id) {
        return clientDAO.deleteClient(id);
    }
}
