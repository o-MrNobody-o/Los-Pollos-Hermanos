package model;

import dao.DrinkDAO;
import entity.Drink;

import java.util.List;

public class DrinkModel {
    private DrinkDAO drinkDAO;

    public DrinkModel() {
        drinkDAO = new DrinkDAO();
    }

    public boolean createDrink(Drink drink) {
        return drinkDAO.addDrink(drink);
    }

    public List<Drink> getAllDrinks() {
        return drinkDAO.getAllDrinks();
    }

    public Drink getDrinkById(int id) {
        return drinkDAO.getDrinkById(id);
    }

    public boolean updateDrink(Drink drink) {
        return drinkDAO.updateDrink(drink);
    }

    public boolean deleteDrink(int id) {
        return drinkDAO.deleteDrink(id);
    }
}
