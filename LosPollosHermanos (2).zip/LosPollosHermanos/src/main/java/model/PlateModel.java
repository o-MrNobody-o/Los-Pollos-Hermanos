package model;

import dao.PlateDAO;
import entity.Plate;

import java.util.List;

public class PlateModel {
    private PlateDAO plateDAO;

    public PlateModel() {
        plateDAO = new PlateDAO();
    }

    public boolean createPlate(Plate plate) {
        return plateDAO.addPlate(plate);
    }

    public List<Plate> getAllPlates() {
        return plateDAO.getAllPlates();
    }

    public Plate getPlateById(int id) {
        return plateDAO.getPlateById(id);
    }

    public boolean updatePlate(Plate plate) {
        return plateDAO.updatePlate(plate);
    }

    public boolean deletePlate(int id) {
        return plateDAO.deletePlate(id);
    }
}
